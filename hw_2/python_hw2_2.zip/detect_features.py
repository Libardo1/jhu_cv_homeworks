import cv2
import numpy as np
import matplotlib.pyplot as plt


def detect_features(image):
	"""
	Computer Vision 600.461/661 Assignment 2
	Args:
		image (numpy.ndarray): The input image to detect features on. Note: this is NOT the image name or image path.
	Returns:
		pixel_coords (list of tuples): A list of (row,col) tuples of detected feature locations in the image
	"""
	pixel_coords = list()

	return pixel_coords
